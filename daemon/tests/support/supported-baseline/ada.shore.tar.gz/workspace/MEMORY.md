Remember this supported baseline.
