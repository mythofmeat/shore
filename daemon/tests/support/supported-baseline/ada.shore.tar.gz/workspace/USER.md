Synthetic archive fixture.
